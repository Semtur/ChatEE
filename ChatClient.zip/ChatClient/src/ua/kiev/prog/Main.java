package ua.kiev.prog;

import java.io.IOException;
import java.io.InputStream;
import java.net.*;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

class GetThread extends Thread {
	private static CookieManager cm;
	GetThread(CookieManager cm) {
		this.cm = cm;
	}
	private int n;
	@Override
	public void run() {
		try {
			while (!isInterrupted()) {
				URL url = new URL("http://localhost:8080/get?from=" + n);
				HttpURLConnection http = (HttpURLConnection) url.openConnection();
				int res = http.getResponseCode();
				if (res == 200) {
					try (InputStream is = http.getInputStream()) {
						int sz = is.available();
						if (sz > 0) {
							byte[] buf = new byte[is.available()];
							is.read(buf);
							Gson gson = new GsonBuilder().create();
							Message[] list = gson.fromJson(new String(buf), Message[].class);
							for (Message m : list) {
								System.out.println(m);
								n++;
							}
						}
					}
					sleep(1000);
				}
				else {
					System.out.println("HTTP error: " + res);
					interrupt();
				}

			}
		} catch (Exception ex) {
			ex.printStackTrace();
			return;
		}
	}
}
public class Main {
	private static CookieManager cm;
	static {
		cm = new CookieManager();
		CookieHandler.setDefault(cm);
	}
	public static void main(String[] args) {
		String login = null;
		Scanner scanner = new Scanner(System.in);
		while(true){
			System.out.println("Please make choice.");
			System.out.println("1. Login to Chat.");
			System.out.println("2. Start Chat.");
			System.out.println("3. Logout from Chat.");
			System.out.println("4. Get UserList.");
			System.out.println("5. Check user status.");
			System.out.println("6. Set your status.");
			System.out.println("7. Enter in a Chat Room.");
			System.out.println("0. Exit.");
			int choice = scanner.nextInt();
			switch (choice) {
				case 0:
					logOut();
					scanner.close();
					return;
				case 1:
					login = logOn();
					break;
				case 2:
					startChat(login);
					break;
				case 3:
					if (logOut() == 0)
						login = null;
					break;
				case 4:
					try {
						User[] users = getUsersList();
						for (User user : users)
							System.out.println(user);
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case 5:
					try {
						getUserStatus();
					} catch (IOException e) {
						e.printStackTrace();
					}
					break;
				case 6:
					try {
						setUserStatus();
					} catch (IOException e) {
						e.printStackTrace();
					}
					break;
				case 7:
					scanner = new Scanner(System.in);
					System.out.print("Please, enter the Chat name: ");
					String chatName = scanner.nextLine();
					System.out.print("Please, enter the password of Chat " + chatName + ": ");
					String chatPassword = scanner.nextLine();
					try {
						URL url = new URL("http://localhost:8080/addchat?chat=" + chatName + "&password=" + chatPassword);
						HttpURLConnection http = (HttpURLConnection) url.openConnection();
						http.setRequestMethod("POST");
						int res = http.getResponseCode();
						if (res != 200)
							System.out.println("HTTP error: " + res);
					} catch (IOException e) {
						e.printStackTrace();
					}
					break;
				default:
					System.out.println("You made wrong choice!");
					break;
			}
		}
	}
	private static String logOn() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter login: ");
		String login = scanner.nextLine();
		System.out.print("Enter password: ");
		String password = scanner.nextLine();
		int res = 0;
		try {
			URL url = new URL("http://localhost:8080/login?login=" + login + "&password=" + password);
			HttpURLConnection http = (HttpURLConnection) url.openConnection();
			http.setRequestMethod("POST");
			res = http.getResponseCode();
			return login;
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		if (res != 200)
			System.out.println("HTTP error: " + res);
		return null;
	}
	private static void startChat(String login) {
		GetThread th = new GetThread(cm);
		th.setDaemon(true);
		th.start();
		Scanner scanner = new Scanner(System.in);
		while (true) {
			String text = scanner.nextLine();
			if (text.isEmpty())
				System.out.println("Empty messages isn't allowed!");
			else if (text.equals("@exit"))
				break;
			else {
				Message m = new Message();
				if (text.startsWith("@chat-")) {
					int i = text.indexOf(":");
					m.setChatName(text.substring(6, i));
					text = text.substring(++i, text.length());
				} else if (text.startsWith("@")) {
					int i = text.indexOf(":");
					m.setTo(text.substring(1, i));
					text = text.substring(++i, text.length());
					System.out.println(m.getTo());
					System.out.println(text);
				}
				m.setFrom(login);
				m.setText(text);
				try {
					int res = m.send("http://localhost:8080/add");
					if (res != 200) {
						System.out.println("HTTP error: " + res);
						break;
					}
				} catch (IOException ex) {
					System.out.println("Error: " + ex.getMessage());
				}
			}
		}
	}
	private static int logOut() {
		try {
			URL url = new URL("http://localhost:8080/login?a=exit");
			HttpURLConnection http = (HttpURLConnection) url.openConnection();
			http.setRequestMethod("GET");
			int res = http.getResponseCode();
			if (res != 200) {
				System.out.println("HTTP error: " + res);
				return -1;
			} else
				return 0;
		} catch (IOException e) {
			e.printStackTrace();
			return -1;
		}
	}
	private static User[] getUsersList() throws IOException {
		URL url = new URL("http://localhost:8080/users");
		HttpURLConnection http = (HttpURLConnection) url.openConnection();
		http.setRequestMethod("GET");
		InputStream is = http.getInputStream();
		int sz = is.available();
		if (sz > 0) {
			byte[] buf = new byte[is.available()];
			is.read(buf);
			Gson gson = new GsonBuilder().create();
			return gson.fromJson(new String(buf), User[].class);
		}
		else
			return null;
	}
	private static void getUserStatus() throws IOException {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please, enter the user name.");
		String userName = scanner.nextLine();
		boolean userFound = false;
		User[] users = getUsersList();
		for (User user : users)
			if (userName.equals(user.getLogin())) {
				System.out.println(userName + " is " + user.getStatus());
				userFound = true;
				break;
			}
		if(!userFound)
			System.out.println("User with name " + userName + " din't find!");
	}
	private static void setUserStatus() throws IOException {
		Scanner scanner = new Scanner(System.in);
			System.out.print("Please, enter your new status: ");
			String status = scanner.nextLine();
			URL url = new URL("http://localhost:8080/users?status=" + status);
			HttpURLConnection http = (HttpURLConnection) url.openConnection();
			http.setRequestMethod("POST");
			int res = http.getResponseCode();
			if (res != 200)
				System.out.println("HTTP error: " + res);
	}
}
