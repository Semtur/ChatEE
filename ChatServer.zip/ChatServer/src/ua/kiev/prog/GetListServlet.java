package ua.kiev.prog;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class GetListServlet extends HttpServlet {
	private MessageList msgList = MessageList.getInstance();
	private UserList userList = UserList.getInstance();
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String chatName = null;
		String userName = null;
		boolean userAuth = false;
		Cookie[] cookies = req.getCookies();
		if (cookies != null)
			for (Cookie cookie : cookies) {
				if (cookie.getName().equals("username")) {
					userName = cookie.getValue();
					for (User user : userList.getUsers())
						if (userName.equals(user.getLogin())) {
							userAuth = user.isCookie();
							break;
						}
				} else if (cookie.getName().equals("chat")) {
					String[] string = cookie.getValue().split("@");
					userName = string[0];
					chatName = string[1];
					for (User user : userList.getUsers())
						if (userName.equals(user.getLogin())) {
							userAuth = user.isCookie();
							break;
						}
				}
			}
		if (userAuth) {
			String fromStr = req.getParameter("from");
			int from = Integer.parseInt(fromStr);
			String json = msgList.toJSON(from, userName, chatName);
			if (json != null) {
				OutputStream os = resp.getOutputStream();
				os.write(json.getBytes());
			}
		}
		else
			resp.sendError(401);
	}
}
