package ua.kiev.prog;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.ArrayList;
import java.util.List;

public class UserList {
    private static final UserList userList = new UserList();
    private final ArrayList<User> list = new ArrayList<>();
    public static UserList getInstance() {
        return userList;
    }
    private UserList(){}
    public synchronized void addUser(User user) {
        list.add(user);
    }
    public synchronized ArrayList<User> getUsers(){return list;}
    public synchronized String toJSON() {
        List<User> res = new ArrayList<>();
        for (User user : list) {
            user.setPassword("");
            res.add(user);
        }
        if (res.size() > 0) {
            Gson gson = new GsonBuilder().create();
            return gson.toJson(res.toArray());
        } else
            return null;
    }
}
