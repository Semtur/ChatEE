package ua.kiev.prog;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;

public class UsersServlet extends HttpServlet {
    private UserList userList = UserList.getInstance();
    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String json = userList.toJSON();
        if (json != null) {
            OutputStream os = resp.getOutputStream();
            os.write(json.getBytes());
        }
    }
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Cookie[] cookies = req.getCookies();
        boolean userNotFound = true;
        if (cookies != null)
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("username")) {
                    String userName = cookie.getValue();
                    for (User user : userList.getUsers()) {
                        if (userName.equals(user.getLogin())) {
                            userNotFound = false;
                            if (user.isCookie())
                                user.setStatus(req.getParameter("status"));
                            else
                                resp.sendError(403);
                            break;
                        }
                    }
                    break;
                }
            }
        if (userNotFound)
            resp.sendError(400);
    }
}
