package ua.kiev.prog;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import javax.servlet.http.*;

public class AddServlet extends HttpServlet {

	private MessageList msgList = MessageList.getInstance();
    private UserList userList = UserList.getInstance();
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		InputStream is = req.getInputStream();
		byte[] buf = new byte[req.getContentLength()];
		is.read(buf);
		String userName = null;
		String chatName = null;
		boolean userAuth = false;
		Cookie[] cookies = req.getCookies();
        if (cookies != null)
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("username")) {
                     userName = cookie.getValue();
                    for (User user : userList.getUsers()) {
                        if (userName.equals(user.getLogin())) {
                            userAuth = user.isCookie();
                            break;
                        }
                    }
                    break;
                } else if (cookie.getName().equals("chat")) {
					String string = cookie.getValue();
					int i = string.indexOf("@");
					chatName = string.substring(++i, string.length());
					for (User user : userList.getUsers())
						if (user.getLogin().equals(userName)) {
							userAuth = user.isCookie();
							break;
						}
				}
            }
		if (userAuth) {
			Message msg = Message.fromJSON(new String(buf));
			if (msg != null) {
				String chatRoomName = msg.getChatName();
				if (chatRoomName == null || chatRoomName.equals(chatName))
					msgList.add(msg);
			}
			else
				resp.setStatus(400);
		} else
			resp.sendError(401);
	}
}
