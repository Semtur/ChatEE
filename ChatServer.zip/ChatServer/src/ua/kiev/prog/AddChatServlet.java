package ua.kiev.prog;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

public class AddChatServlet extends HttpServlet {
    private static HashMap<String, String> hm = new HashMap<>();
    private UserList userList = UserList.getInstance();
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        boolean userAuth = false;
        Cookie[] cookies = req.getCookies();
        String userName = null;
        if (cookies != null)
            for (Cookie c : cookies)
                if (c.getName().equals("username"))
                    for (User user : userList.getUsers()) {
                        userName = user.getLogin();
                        if (userName.equals(c.getValue())) {
                            userAuth = user.isCookie();
                            break;
                        }
                    }
        if (userAuth) {
            String chatName = req.getParameter("chat");
            String chatPassword = req.getParameter("password");
            if (!hm.containsKey(chatName)) {
                hm.put(chatName, chatPassword);
                resp.addCookie(setCookie(userName, chatName));
            } else if (!chatPassword.isEmpty() && chatPassword.equals(hm.get(chatName))) {
                resp.addCookie(setCookie(userName, chatName));
            } else {
                resp.setStatus(400);
            }
        } else
            resp.sendError(401);
    }
    private Cookie setCookie(String userName, String chatName) {
        String string = new StringBuilder().append(userName).append("@").append(chatName).toString();
        return new Cookie("chat", string);
    }
}
