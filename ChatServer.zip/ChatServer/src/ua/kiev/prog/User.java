package ua.kiev.prog;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.Serializable;

public class User implements Serializable {
    private static final long serialVersionUID = 1L;
    private String login;
    private String password;
    private String status;
    private boolean cookie;
    public User(String login, String password, boolean cookie){
        this.login = login;
        this.password = password;
        this.cookie = cookie;
        if (isCookie())
            status = "online";
        else
            status = "offline";
    }
    public String getLogin(){
        return login;
    }
    public String getPassword(){
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public void setCookie(boolean cookie){
        this.cookie = cookie;
        if (cookie)
            status = "online";
        else
            status = "offline";
    }
    public boolean isCookie(){
        return cookie;
    }
    public static User fromJSON(String s) {
        Gson gson = new GsonBuilder().create();
        return gson.fromJson(s, User.class);
    }
    @Override
    public String toString() {
        return new StringBuilder().append("user: ").append(login).append(" - ").append(status).toString();
    }
}
