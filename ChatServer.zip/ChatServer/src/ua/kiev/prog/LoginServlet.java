package ua.kiev.prog;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.http.*;

public class LoginServlet extends javax.servlet.http.HttpServlet {
    private UserList userList = UserList.getInstance();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        String login = request.getParameter("login");
        String password = request.getParameter("password");
        ArrayList<User> users = userList.getUsers();
        Cookie cookie;
        if (users.isEmpty()) {
            cookie = new Cookie("username", login);
            User user = new User(login, password, true);
            userList.addUser(user);
            response.addCookie(cookie);
        } else {
            boolean userFound = false;
            for (User user: users) {
                if (login.equals(user.getLogin())) {
                    userFound = true;
                    if (password.equals(user.getPassword())) {
                        cookie = new Cookie("username", login);
                        response.addCookie(cookie);
                        user.setCookie(true);
                        break;
                    } else {
                        response.sendError(401);
                        break;
                    }
                }
            }
            if (!userFound) {
                cookie = new Cookie("username", login);
                User user = new User(login, password, true);
                userList.addUser(user);
                response.addCookie(cookie);
            }
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        String a = request.getParameter("a");
        Cookie[] cookies = request.getCookies();
        String login = null;
        if (cookies != null)
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("username")) {
                    login = cookie.getValue();
                    break;
                }
            }
        if ("exit".equals(a) && (login != null)) {
            ArrayList<User> users = userList.getUsers();
            for (User usr: users) {
                if(login.equals(usr.getLogin())) {
                    usr.setCookie(false);
                    response.setStatus(200);
                    break;
                }

            }
        } else
            response.sendError(400);
    }
}
